import SectionTitle from "../../../components/SectionTitle";


const Payment = () => {
    return (
        <div>
            <SectionTitle subHeading={"Please Process payment"} heading={"Payment"}></SectionTitle>
            <h2>Payment</h2>
        </div>
    );
};

export default Payment;